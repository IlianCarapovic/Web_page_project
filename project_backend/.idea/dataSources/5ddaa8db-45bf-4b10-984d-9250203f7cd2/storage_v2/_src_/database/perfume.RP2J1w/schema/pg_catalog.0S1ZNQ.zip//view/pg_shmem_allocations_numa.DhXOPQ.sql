create view pg_shmem_allocations_numa(name, numa_node, size) as
SELECT name,
       numa_node,
       size
FROM pg_get_shmem_allocations_numa() pg_get_shmem_allocations_numa(name, numa_node, size);

alter table pg_shmem_allocations_numa
    owner to postgres;

grant select on pg_shmem_allocations_numa to pg_read_all_stats;

