create view pg_aios
            (pid, io_id, io_generation, state, operation, "off", length, target, handle_data_len, raw_result, result,
             target_desc, f_sync, f_localmem, f_buffered)
as
SELECT pid,
       io_id,
       io_generation,
       state,
       operation,
        off,
        length,
        target,
        handle_data_len,
        raw_result,
        result,
        target_desc,
        f_sync,
        f_localmem,
        f_buffered
        FROM pg_get_aios() pg_get_aios(pid, io_id, io_generation, state, operation, off, length, target, handle_data_len, raw_result, result, target_desc, f_sync, f_localmem, f_buffered);

alter table pg_aios
    owner to postgres;

grant select on pg_aios to pg_read_all_stats;

